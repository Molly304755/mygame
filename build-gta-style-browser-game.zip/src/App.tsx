import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";

type Phase = "menu" | "playing" | "paused" | "gameover";
type Vec = { x: number; y: number };
type Rect = { x: number; y: number; w: number; h: number };
type Car = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  health: number;
  boost: number;
  damageCooldown: number;
  trailTimer: number;
  boosting: boolean;
};
type Cop = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  hitCooldown: number;
  stall: number;
  siren: number;
};
type Pickup = { id: number; x: number; y: number; phase: number };
type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
};
type FloatText = { x: number; y: number; text: string; color: string; life: number; maxLife: number };
type RecordEntry = { name: string; score: number; distance: number; date: string };
type Runtime = {
  player: Car;
  cops: Cop[];
  pickups: Pickup[];
  particles: Particle[];
  texts: FloatText[];
  score: number;
  wanted: number;
  distance: number;
  bust: number;
  visualTime: number;
  cameraX: number;
  cameraY: number;
  shake: number;
  pickupCount: number;
  pickupId: number;
  pickupSpawnTimer: number;
  copSpawnTimer: number;
  driftTimer: number;
  busted: boolean;
};
type InputFrame = { throttle: number; steer: number; drift: boolean; boost: boolean };
type SoundKind = "pickup" | "boost" | "impact" | "busted";
type HudSnapshot = { score: number; health: number; boost: number; wanted: number; bust: number; speed: number; cops: number; pickupCount: number };

const GRID = 510;
const ROAD = 138;
const ROAD_HALF = ROAD / 2;
const RECORD_KEY = "night-shift-local-records-v1";
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const wrapAngle = (angle: number) => Math.atan2(Math.sin(angle), Math.cos(angle));
const formatMoney = (value: number) => `$${Math.max(0, Math.floor(value)).toLocaleString("en-US")}`;

function hash2(x: number, y: number) {
  const raw = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return raw - Math.floor(raw);
}

function createRuntime(): Runtime {
  const drops = [
    [0, -215],
    [205, 0],
    [-210, 0],
    [0, 220],
    [510, 100],
    [-510, -120],
    [270, 510],
    [-255, -510],
    [510, -510],
  ];
  return {
    player: {
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      angle: -Math.PI / 2,
      health: 100,
      boost: 58,
      damageCooldown: 0,
      trailTimer: 0,
      boosting: false,
    },
    cops: [],
    pickups: drops.map(([x, y], id) => ({ x, y, id, phase: hash2(id, 4) * Math.PI * 2 })),
    particles: [],
    texts: [],
    score: 0,
    wanted: 0,
    distance: 0,
    bust: 0,
    visualTime: 0,
    cameraX: 0,
    cameraY: 0,
    shake: 0,
    pickupCount: 0,
    pickupId: drops.length,
    pickupSpawnTimer: 1.8,
    copSpawnTimer: 0,
    driftTimer: 0,
    busted: false,
  };
}

function makeHud(game: Runtime): HudSnapshot {
  return {
    score: game.score,
    health: game.player.health,
    boost: game.player.boost,
    wanted: game.wanted,
    bust: game.bust,
    speed: Math.round(Math.hypot(game.player.vx, game.player.vy) * 0.48),
    cops: game.cops.length,
    pickupCount: game.pickupCount,
  };
}

function readRecords(): RecordEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(RECORD_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item): item is RecordEntry => {
        if (!item || typeof item !== "object") return false;
        const row = item as Record<string, unknown>;
        return typeof row.name === "string" && typeof row.score === "number" && typeof row.distance === "number" && typeof row.date === "string";
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  } catch {
    return [];
  }
}

function getBlockDesign(bx: number, by: number) {
  const left = bx * GRID + ROAD_HALF + 10;
  const top = by * GRID + ROAD_HALF + 10;
  const width = GRID - ROAD - 20;
  const height = width;
  const roll = hash2(bx, by);
  const park = roll < 0.12;
  const variant = Math.floor(roll * 100) % 4;
  const rects: Rect[] = [];

  if (!park) {
    if (variant === 0) {
      rects.push({ x: left + 23, y: top + 21, w: width - 46, h: height - 42 });
    } else if (variant === 1) {
      const gap = 16;
      const half = (width - 34 - gap) / 2;
      rects.push({ x: left + 17, y: top + 19, w: half, h: height - 38 });
      rects.push({ x: left + 17 + half + gap, y: top + 19, w: half, h: height - 38 });
    } else if (variant === 2) {
      const halfW = (width - 44) / 2;
      const halfH = (height - 44) / 2;
      rects.push({ x: left + 16, y: top + 17, w: halfW, h: halfH });
      rects.push({ x: left + 28 + halfW, y: top + 17, w: halfW, h: halfH });
      rects.push({ x: left + 16, y: top + 27 + halfH, w: width - 32, h: halfH });
    } else {
      rects.push({ x: left + 17, y: top + 17, w: width * 0.42, h: height - 34 });
      rects.push({ x: left + width * 0.47, y: top + 17, w: width * 0.47 - 17, h: height * 0.43 });
      rects.push({ x: left + width * 0.47, y: top + height * 0.56, w: width * 0.47 - 17, h: height * 0.39 - 17 });
    }
  }

  return { left, top, width, height, park, variant, rects, palette: Math.floor(hash2(bx + 12, by - 9) * 5) };
}

const buildingColors = [
  { wall: "#465057", roof: "#657078", trim: "#9aa3a0", dark: "#343c42" },
  { wall: "#4a4c47", roof: "#716e62", trim: "#b1aa91", dark: "#343832" },
  { wall: "#3c4f50", roof: "#597071", trim: "#8ea8a0", dark: "#2c3b3d" },
  { wall: "#4d4241", roof: "#705a55", trim: "#b38d7d", dark: "#392f30" },
  { wall: "#41474f", roof: "#5d6876", trim: "#98a5b1", dark: "#30363f" },
];

function resolveBuildingCollision(car: { x: number; y: number }, radius: number) {
  let collided = false;
  const bx = Math.floor(car.x / GRID);
  const by = Math.floor(car.y / GRID);
  for (let pass = 0; pass < 2; pass += 1) {
    for (let iy = by - 1; iy <= by + 1; iy += 1) {
      for (let ix = bx - 1; ix <= bx + 1; ix += 1) {
        const design = getBlockDesign(ix, iy);
        for (const rect of design.rects) {
          const closestX = clamp(car.x, rect.x, rect.x + rect.w);
          const closestY = clamp(car.y, rect.y, rect.y + rect.h);
          let dx = car.x - closestX;
          let dy = car.y - closestY;
          let distance = Math.hypot(dx, dy);
          if (distance >= radius) continue;
          if (distance < 0.001) {
            const left = car.x - rect.x;
            const right = rect.x + rect.w - car.x;
            const top = car.y - rect.y;
            const bottom = rect.y + rect.h - car.y;
            const nearest = Math.min(left, right, top, bottom);
            if (nearest === left) dx = -1;
            else if (nearest === right) dx = 1;
            else if (nearest === top) dy = -1;
            else dy = 1;
            distance = 1;
          }
          const nx = dx / distance;
          const ny = dy / distance;
          const penetration = radius - distance + 1;
          car.x += nx * penetration;
          car.y += ny * penetration;
          collided = true;
        }
      }
    }
  }
  return collided;
}

function burst(game: Runtime, x: number, y: number, count: number, colors: string[], power = 130) {
  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const speed = power * (0.25 + Math.random() * 0.9);
    const life = 0.28 + Math.random() * 0.58;
    game.particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life,
      maxLife: life,
      size: 1.8 + Math.random() * 4.6,
      color: colors[Math.floor(Math.random() * colors.length)],
    });
  }
  if (game.particles.length > 300) game.particles.splice(0, game.particles.length - 300);
}

function addText(game: Runtime, x: number, y: number, text: string, color: string) {
  game.texts.push({ x, y, text, color, life: 1.1, maxLife: 1.1 });
  if (game.texts.length > 14) game.texts.shift();
}

function spawnCop(game: Runtime) {
  const player = game.player;
  const horizontal = Math.random() < 0.5;
  const sign = Math.random() < 0.5 ? -1 : 1;
  let x: number;
  let y: number;
  if (horizontal) {
    x = player.x + sign * (440 + Math.random() * 140);
    y = Math.round(player.y / GRID) * GRID + (Math.random() < 0.5 ? -30 : 30);
  } else {
    x = Math.round(player.x / GRID) * GRID + (Math.random() < 0.5 ? -30 : 30);
    y = player.y + sign * (440 + Math.random() * 140);
  }
  const angle = Math.atan2(player.y - y, player.x - x);
  game.cops.push({ x, y, vx: 0, vy: 0, angle, hitCooldown: 0.2, stall: 0, siren: Math.random() * Math.PI * 2 });
}

function getCopTarget(cop: Cop, player: Car): Vec {
  const playerNodeX = Math.round(player.x / GRID) * GRID;
  const playerNodeY = Math.round(player.y / GRID) * GRID;
  const playerOnHorizontal = Math.abs(player.y - playerNodeY) <= Math.abs(player.x - playerNodeX);
  const copNodeX = Math.round(cop.x / GRID) * GRID;
  const copNodeY = Math.round(cop.y / GRID) * GRID;
  const nodeDx = Math.abs(cop.x - copNodeX);
  const nodeDy = Math.abs(cop.y - copNodeY);
  const atJunction = nodeDx < ROAD_HALF && nodeDy < ROAD_HALF;
  const onHorizontal = atJunction ? Math.abs(Math.cos(cop.angle)) >= Math.abs(Math.sin(cop.angle)) : nodeDy < nodeDx;

  if (onHorizontal) {
    if (playerOnHorizontal && copNodeY === playerNodeY) return { x: player.x, y: playerNodeY };
    if (Math.abs(cop.x - playerNodeX) > 42) return { x: playerNodeX, y: copNodeY };
    return playerOnHorizontal ? { x: playerNodeX, y: playerNodeY } : { x: playerNodeX, y: player.y };
  }

  if (!playerOnHorizontal && copNodeX === playerNodeX) return { x: playerNodeX, y: player.y };
  if (Math.abs(cop.y - playerNodeY) > 42) return { x: copNodeX, y: playerNodeY };
  return playerOnHorizontal ? { x: player.x, y: playerNodeY } : { x: playerNodeX, y: playerNodeY };
}

function updateGame(game: Runtime, dt: number, input: InputFrame, onSound: (kind: SoundKind) => void) {
  const player = game.player;
  game.visualTime += dt;
  player.damageCooldown = Math.max(0, player.damageCooldown - dt);
  player.trailTimer -= dt;

  const forwardX = Math.cos(player.angle);
  const forwardY = Math.sin(player.angle);
  let forwardSpeed = player.vx * forwardX + player.vy * forwardY;
  let sideSpeed = player.vx * -forwardY + player.vy * forwardX;
  const wantsBoost = input.boost && input.throttle > 0.05 && player.boost > 0;
  if (wantsBoost && !player.boosting) onSound("boost");
  player.boosting = wantsBoost;

  if (input.throttle > 0) forwardSpeed += 520 * input.throttle * dt;
  else if (input.throttle < 0) forwardSpeed += 410 * input.throttle * dt;
  else forwardSpeed *= Math.exp(-0.64 * dt);
  if (wantsBoost) forwardSpeed += 330 * input.throttle * dt;
  sideSpeed *= Math.exp(-(input.drift ? 1.18 : 7.2) * dt);

  const turnSign = forwardSpeed < -8 ? -1 : 1;
  const pace = 0.42 + Math.min(Math.abs(forwardSpeed) / 155, 1.45);
  player.angle += input.steer * pace * (input.drift ? 1.35 : 1) * turnSign * dt;
  const maxSpeed = wantsBoost ? 438 : 294;
  forwardSpeed = clamp(forwardSpeed, -142, maxSpeed);
  const updatedForwardX = Math.cos(player.angle);
  const updatedForwardY = Math.sin(player.angle);
  player.vx = updatedForwardX * forwardSpeed - updatedForwardY * sideSpeed;
  player.vy = updatedForwardY * forwardSpeed + updatedForwardX * sideSpeed;

  if (wantsBoost) player.boost = Math.max(0, player.boost - 37 * dt);
  else player.boost = Math.min(100, player.boost + 7.5 * dt);

  const oldX = player.x;
  const oldY = player.y;
  const impact = Math.hypot(player.vx, player.vy);
  player.x += player.vx * dt;
  player.y += player.vy * dt;
  if (resolveBuildingCollision(player, 14)) {
    player.vx *= -0.16;
    player.vy *= -0.16;
    if (player.damageCooldown <= 0 && impact > 75) {
      player.health = Math.max(0, player.health - clamp(impact * 0.035, 5, 14));
      player.damageCooldown = 0.65;
      game.shake = Math.max(game.shake, clamp(impact / 19, 5, 16));
      burst(game, (player.x + oldX) / 2, (player.y + oldY) / 2, 14, ["#fff4b0", "#ff785e", "#dce7e8"], 170);
      onSound("impact");
    }
  }

  const speed = Math.hypot(player.vx, player.vy);
  game.distance += speed * dt;
  if (player.boosting && player.trailTimer <= 0) {
    const rearX = player.x - Math.cos(player.angle) * 20;
    const rearY = player.y - Math.sin(player.angle) * 20;
    burst(game, rearX, rearY, 2, ["#54d9ff", "#c5ff6a", "#ffffff"], 46);
    game.shake = Math.max(game.shake, 1.5);
    player.trailTimer = 0.045;
  }
  if (input.drift && speed > 125) {
    game.driftTimer -= dt;
    if (game.driftTimer <= 0) {
      const rearX = player.x - Math.cos(player.angle) * 13;
      const rearY = player.y - Math.sin(player.angle) * 13;
      burst(game, rearX, rearY, 3, ["#9ca7a5", "#d4d4c5", "#777f7d"], 36);
      game.driftTimer = 0.08;
    }
  }

  for (let i = game.pickups.length - 1; i >= 0; i -= 1) {
    const drop = game.pickups[i];
    if (Math.hypot(player.x - drop.x, player.y - drop.y) < 29) {
      game.pickups.splice(i, 1);
      game.score += 300;
      game.pickupCount += 1;
      game.wanted = Math.min(5, game.wanted + 0.72);
      player.boost = Math.min(100, player.boost + 24);
      game.shake = Math.max(game.shake, 7);
      burst(game, drop.x, drop.y, 24, ["#e7ff68", "#c6fa4b", "#fef8c4", "#ffffff"], 185);
      addText(game, drop.x, drop.y - 12, "+$300", "#dfff67");
      addText(game, drop.x, drop.y + 15, "HEAT UP", "#ff785e");
      game.pickupSpawnTimer = Math.min(game.pickupSpawnTimer, 0.75);
      onSound("pickup");
      if (typeof navigator !== "undefined") navigator.vibrate?.(18);
    }
  }

  game.pickupSpawnTimer -= dt;
  if (game.pickupSpawnTimer <= 0 && game.pickups.length < 7) {
    const horizontal = Math.random() < 0.5;
    const sign = Math.random() < 0.5 ? -1 : 1;
    const distance = 330 + Math.random() * 520;
    const x = horizontal ? player.x + sign * distance : Math.round(player.x / GRID) * GRID;
    const y = horizontal ? Math.round(player.y / GRID) * GRID : player.y + sign * distance;
    if (!game.pickups.some((drop) => Math.hypot(drop.x - x, drop.y - y) < 120)) {
      game.pickups.push({ x, y, id: game.pickupId++, phase: Math.random() * Math.PI * 2 });
    }
    game.pickupSpawnTimer = 2.6;
  }

  game.wanted = Math.max(0, game.wanted - 0.018 * dt);
  game.copSpawnTimer -= dt;
  const desiredCops = game.wanted < 0.18 ? 0 : Math.min(4, 1 + Math.floor(game.wanted / 1.28));
  if (game.cops.length < desiredCops && game.copSpawnTimer <= 0) {
    spawnCop(game);
    game.copSpawnTimer = 1.35;
  }

  for (let i = game.cops.length - 1; i >= 0; i -= 1) {
    const cop = game.cops[i];
    cop.hitCooldown = Math.max(0, cop.hitCooldown - dt);
    cop.siren += dt * 8.5;
    const target = getCopTarget(cop, player);
    const dx = target.x - cop.x;
    const dy = target.y - cop.y;
    const targetAngle = Math.atan2(dy, dx);
    const turn = wrapAngle(targetAngle - cop.angle);
    cop.angle += clamp(turn, -2.65 * dt, 2.65 * dt);
    const currentSpeed = Math.hypot(cop.vx, cop.vy);
    const targetSpeed = 178 + game.wanted * 12;
    const nextSpeed = currentSpeed + (targetSpeed - currentSpeed) * Math.min(1, dt * 1.4);
    cop.vx = Math.cos(cop.angle) * nextSpeed;
    cop.vy = Math.sin(cop.angle) * nextSpeed;
    cop.x += cop.vx * dt;
    cop.y += cop.vy * dt;
    if (resolveBuildingCollision(cop, 15)) {
      cop.vx *= -0.12;
      cop.vy *= -0.12;
      cop.angle += (Math.random() - 0.5) * 1.25;
      cop.stall = 0.45;
    }
    cop.stall = Math.max(0, cop.stall - dt);
    if (Math.hypot(cop.x - player.x, cop.y - player.y) > 1540) {
      game.cops.splice(i, 1);
      continue;
    }

    const contact = Math.hypot(cop.x - player.x, cop.y - player.y);
    if (contact < 38 && cop.hitCooldown <= 0) {
      cop.hitCooldown = 0.9;
      player.health = Math.max(0, player.health - 13);
      player.damageCooldown = Math.max(player.damageCooldown, 0.45);
      const shove = Math.atan2(player.y - cop.y, player.x - cop.x);
      player.vx += Math.cos(shove) * 145;
      player.vy += Math.sin(shove) * 145;
      game.shake = Math.max(game.shake, 12);
      burst(game, (player.x + cop.x) / 2, (player.y + cop.y) / 2, 20, ["#ff594f", "#48cfff", "#fff2b0"], 190);
      addText(game, player.x, player.y - 25, "UNIT HIT", "#ff7065");
      onSound("impact");
      if (typeof navigator !== "undefined") navigator.vibrate?.([18, 22, 18]);
    }
    if (contact < 62 && speed < 112) game.bust = Math.min(100, game.bust + 32 * dt);
  }
  if (speed >= 112 || game.cops.every((cop) => Math.hypot(cop.x - player.x, cop.y - player.y) > 72)) {
    game.bust = Math.max(0, game.bust - 26 * dt);
  }

  for (let i = game.particles.length - 1; i >= 0; i -= 1) {
    const particle = game.particles[i];
    particle.life -= dt;
    particle.x += particle.vx * dt;
    particle.y += particle.vy * dt;
    particle.vx *= Math.exp(-1.6 * dt);
    particle.vy *= Math.exp(-1.6 * dt);
    if (particle.life <= 0) game.particles.splice(i, 1);
  }
  for (let i = game.texts.length - 1; i >= 0; i -= 1) {
    const text = game.texts[i];
    text.life -= dt;
    text.y -= 33 * dt;
    if (text.life <= 0) game.texts.splice(i, 1);
  }

  game.cameraX += (player.x + player.vx * 0.16 - game.cameraX) * Math.min(1, dt * 5.5);
  game.cameraY += (player.y + player.vy * 0.16 - game.cameraY) * Math.min(1, dt * 5.5);
  game.shake *= Math.exp(-6.5 * dt);
  if (game.shake < 0.2) game.shake = 0;

  if (player.health <= 0 || game.bust >= 100) {
    game.busted = true;
    return true;
  }
  return false;
}

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function drawBuilding(ctx: CanvasRenderingContext2D, rect: Rect, paletteIndex: number, variant: number, visualTime: number) {
  const palette = buildingColors[paletteIndex];
  ctx.fillStyle = "rgba(0,0,0,.28)";
  roundedRect(ctx, rect.x + 6, rect.y + 8, rect.w, rect.h, 6);
  ctx.fill();
  ctx.fillStyle = palette.wall;
  roundedRect(ctx, rect.x, rect.y, rect.w, rect.h, 6);
  ctx.fill();
  ctx.fillStyle = palette.roof;
  roundedRect(ctx, rect.x + 4, rect.y + 4, rect.w - 8, rect.h - 8, 4);
  ctx.fill();
  ctx.strokeStyle = palette.trim;
  ctx.globalAlpha = 0.32;
  ctx.lineWidth = 1;
  ctx.strokeRect(rect.x + 8, rect.y + 8, rect.w - 16, rect.h - 16);
  ctx.globalAlpha = 1;

  const cols = Math.max(2, Math.floor((rect.w - 30) / 26));
  const rows = Math.max(2, Math.floor((rect.h - 30) / 28));
  ctx.fillStyle = palette.dark;
  for (let i = 0; i < cols; i += 1) {
    const px = rect.x + 14 + i * ((rect.w - 28) / Math.max(1, cols - 1));
    ctx.fillRect(px, rect.y + 10, 7, 3);
    ctx.fillRect(px, rect.y + rect.h - 13, 7, 3);
  }
  for (let i = 0; i < rows; i += 1) {
    const py = rect.y + 14 + i * ((rect.h - 28) / Math.max(1, rows - 1));
    ctx.fillRect(rect.x + 10, py, 3, 7);
    ctx.fillRect(rect.x + rect.w - 13, py, 3, 7);
  }

  ctx.fillStyle = "rgba(17,24,26,.38)";
  if (variant % 2 === 0) {
    roundedRect(ctx, rect.x + rect.w * 0.34, rect.y + rect.h * 0.36, rect.w * 0.31, rect.h * 0.24, 4);
    ctx.fill();
    ctx.fillStyle = "rgba(222,231,197,.18)";
    ctx.fillRect(rect.x + rect.w * 0.39, rect.y + rect.h * 0.41, rect.w * 0.2, 2);
  } else {
    ctx.fillRect(rect.x + rect.w * 0.18, rect.y + rect.h * 0.2, rect.w * 0.24, 5);
    ctx.fillRect(rect.x + rect.w * 0.59, rect.y + rect.h * 0.68, rect.w * 0.22, 4);
  }
  const glow = 0.16 + (Math.sin(visualTime * 1.6 + rect.x * 0.01) + 1) * 0.06;
  ctx.fillStyle = `rgba(228, 196, 112, ${glow})`;
  ctx.fillRect(rect.x + 12, rect.y + 12, 2, 2);
}

function drawPark(ctx: CanvasRenderingContext2D, design: ReturnType<typeof getBlockDesign>, bx: number, by: number, time: number) {
  const { left, top, width, height } = design;
  ctx.fillStyle = "#354a3a";
  ctx.fillRect(left, top, width, height);
  ctx.strokeStyle = "#78836f";
  ctx.globalAlpha = 0.7;
  ctx.lineWidth = 12;
  ctx.beginPath();
  ctx.moveTo(left + 10, top + height * 0.5);
  ctx.lineTo(left + width - 10, top + height * 0.5);
  ctx.moveTo(left + width * 0.5, top + 10);
  ctx.lineTo(left + width * 0.5, top + height - 10);
  ctx.stroke();
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#425e4a";
  roundedRect(ctx, left + width * 0.63, top + height * 0.15, width * 0.2, height * 0.22, 12);
  ctx.fill();
  for (let i = 0; i < 9; i += 1) {
    const tx = left + 30 + hash2(bx + i * 7, by + 2) * (width - 60);
    const ty = top + 30 + hash2(bx - 3, by + i * 11) * (height - 60);
    ctx.fillStyle = "rgba(0,0,0,.24)";
    ctx.beginPath();
    ctx.ellipse(tx + 3, ty + 7, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = i % 3 === 0 ? "#6f8258" : "#4f6c4d";
    ctx.beginPath();
    ctx.arc(tx, ty + Math.sin(time + i) * 1.4, 11, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(198,215,147,.26)";
    ctx.beginPath();
    ctx.arc(tx - 3, ty - 3, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawRoads(ctx: CanvasRenderingContext2D, left: number, top: number, right: number, bottom: number, time: number) {
  const fromY = Math.floor(top / GRID) - 1;
  const toY = Math.ceil(bottom / GRID) + 1;
  const fromX = Math.floor(left / GRID) - 1;
  const toX = Math.ceil(right / GRID) + 1;
  ctx.fillStyle = "#69736d";
  for (let row = fromY; row <= toY; row += 1) ctx.fillRect(left - GRID, row * GRID - ROAD_HALF, right - left + GRID * 2, ROAD);
  for (let col = fromX; col <= toX; col += 1) ctx.fillRect(col * GRID - ROAD_HALF, top - GRID, ROAD, bottom - top + GRID * 2);
  ctx.fillStyle = "#252c30";
  for (let row = fromY; row <= toY; row += 1) ctx.fillRect(left - GRID, row * GRID - ROAD_HALF + 5, right - left + GRID * 2, ROAD - 10);
  for (let col = fromX; col <= toX; col += 1) ctx.fillRect(col * GRID - ROAD_HALF + 5, top - GRID, ROAD - 10, bottom - top + GRID * 2);

  ctx.save();
  ctx.globalAlpha = 0.38;
  ctx.lineWidth = 1.2;
  ctx.setLineDash([18, 22]);
  ctx.lineDashOffset = -time * 12;
  ctx.strokeStyle = "#c8cec2";
  for (let row = fromY; row <= toY; row += 1) {
    for (const offset of [-34, 34]) {
      ctx.beginPath();
      ctx.moveTo(left - GRID, row * GRID + offset);
      ctx.lineTo(right + GRID, row * GRID + offset);
      ctx.stroke();
    }
  }
  for (let col = fromX; col <= toX; col += 1) {
    for (const offset of [-34, 34]) {
      ctx.beginPath();
      ctx.moveTo(col * GRID + offset, top - GRID);
      ctx.lineTo(col * GRID + offset, bottom + GRID);
      ctx.stroke();
    }
  }
  ctx.setLineDash([9, 13]);
  ctx.lineDashOffset = time * 5;
  ctx.strokeStyle = "#dec975";
  ctx.globalAlpha = 0.46;
  for (let row = fromY; row <= toY; row += 1) {
    ctx.beginPath();
    ctx.moveTo(left - GRID, row * GRID);
    ctx.lineTo(right + GRID, row * GRID);
    ctx.stroke();
  }
  for (let col = fromX; col <= toX; col += 1) {
    ctx.beginPath();
    ctx.moveTo(col * GRID, top - GRID);
    ctx.lineTo(col * GRID, bottom + GRID);
    ctx.stroke();
  }
  ctx.restore();
}

function drawCar(ctx: CanvasRenderingContext2D, x: number, y: number, angle: number, kind: "player" | "police" | "traffic", time: number, boosting = false) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  const scale = kind === "traffic" ? 0.84 : 1;
  ctx.scale(scale, scale);
  ctx.fillStyle = "rgba(0,0,0,.48)";
  roundedRect(ctx, -18, -8, 39, 20, 6);
  ctx.fill();

  if (kind === "player") {
    const beam = ctx.createLinearGradient(12, 0, 145, 0);
    beam.addColorStop(0, "rgba(222,255,157,.14)");
    beam.addColorStop(1, "rgba(222,255,157,0)");
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(15, -5);
    ctx.lineTo(145, -58);
    ctx.lineTo(145, 58);
    ctx.lineTo(15, 5);
    ctx.closePath();
    ctx.fill();
  }

  if (boosting && kind === "player") {
    ctx.fillStyle = "rgba(91,223,255,.72)";
    ctx.beginPath();
    ctx.moveTo(-17, -4);
    ctx.lineTo(-34 - Math.sin(time * 35) * 5, 0);
    ctx.lineTo(-17, 4);
    ctx.closePath();
    ctx.fill();
  }

  ctx.fillStyle = "#13191b";
  roundedRect(ctx, -10, -10, 11, 4, 2);
  ctx.fill();
  roundedRect(ctx, 7, -10, 11, 4, 2);
  ctx.fill();
  roundedRect(ctx, -10, 6, 11, 4, 2);
  ctx.fill();
  roundedRect(ctx, 7, 6, 11, 4, 2);
  ctx.fill();

  if (kind === "police") {
    ctx.fillStyle = "#e8e8df";
    roundedRect(ctx, -18, -8, 36, 16, 5);
    ctx.fill();
    ctx.fillStyle = "#27546b";
    ctx.fillRect(-3, -7, 7, 14);
    ctx.fillStyle = "rgba(27,43,53,.92)";
    roundedRect(ctx, -8, -6, 14, 12, 3);
    ctx.fill();
    ctx.fillStyle = Math.sin(time * 13 + angle) > 0 ? "#ff5458" : "#51cfff";
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 12;
    roundedRect(ctx, -3, -8, 7, 3, 1);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#fff8d0";
    ctx.fillRect(15, -5, 3, 3);
    ctx.fillRect(15, 2, 3, 3);
  } else {
    ctx.fillStyle = kind === "player" ? "#d9ef63" : "#839098";
    roundedRect(ctx, -18, -8, 36, 16, 5);
    ctx.fill();
    ctx.strokeStyle = kind === "player" ? "#f4ffbc" : "rgba(229,235,229,.5)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = kind === "player" ? "#182a32" : "#26313a";
    roundedRect(ctx, -8, -6, 15, 12, 3);
    ctx.fill();
    ctx.fillStyle = kind === "player" ? "rgba(157,217,226,.82)" : "rgba(172,194,199,.5)";
    ctx.fillRect(3, -5, 4, 10);
    ctx.fillStyle = "#f1e9bd";
    ctx.fillRect(15, -5, 3, 3);
    ctx.fillRect(15, 2, 3, 3);
    ctx.fillStyle = "#fc6e5e";
    ctx.fillRect(-18, -5, 2, 3);
    ctx.fillRect(-18, 2, 2, 3);
  }
  ctx.restore();
}

function drawTraffic(ctx: CanvasRenderingContext2D, left: number, top: number, right: number, bottom: number, time: number) {
  const rowStart = Math.floor(top / GRID) - 1;
  const rowEnd = Math.ceil(bottom / GRID) + 1;
  for (let row = rowStart; row <= rowEnd; row += 1) {
    const direction = row % 2 === 0 ? 1 : -1;
    const shift = time * direction * 34;
    const horizontalStart = Math.floor((left - shift) / 360) - 1;
    const horizontalEnd = Math.ceil((right - shift) / 360) + 1;
    for (let segment = horizontalStart; segment <= horizontalEnd; segment += 1) {
      const seed = hash2(segment, row);
      const x = segment * 360 + seed * 360 + shift;
      const y = row * GRID + (direction > 0 ? -33 : 33);
      drawCar(ctx, x, y, direction > 0 ? 0 : Math.PI, "traffic", time);
    }
  }
  const colStart = Math.floor(left / GRID) - 1;
  const colEnd = Math.ceil(right / GRID) + 1;
  for (let col = colStart; col <= colEnd; col += 1) {
    const direction = col % 2 === 0 ? 1 : -1;
    const shift = time * direction * 30;
    const verticalStart = Math.floor((top - shift) / 360) - 1;
    const verticalEnd = Math.ceil((bottom - shift) / 360) + 1;
    for (let segment = verticalStart; segment <= verticalEnd; segment += 1) {
      const seed = hash2(col + 90, segment - 40);
      const y = segment * 360 + seed * 360 + shift;
      const x = col * GRID + (direction > 0 ? 33 : -33);
      drawCar(ctx, x, y, direction > 0 ? Math.PI / 2 : -Math.PI / 2, "traffic", time);
    }
  }
}

function drawPickup(ctx: CanvasRenderingContext2D, pickup: Pickup, time: number) {
  const bob = Math.sin(time * 3.2 + pickup.phase) * 4;
  ctx.save();
  ctx.translate(pickup.x, pickup.y + bob);
  ctx.fillStyle = "rgba(211,255,84,.14)";
  ctx.beginPath();
  ctx.arc(0, 0, 25 + Math.sin(time * 4 + pickup.phase) * 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(0,0,0,.35)";
  ctx.beginPath();
  ctx.ellipse(0, 12, 14, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.rotate(Math.sin(time * 1.4 + pickup.phase) * 0.12);
  ctx.shadowColor = "#d7fa58";
  ctx.shadowBlur = 18;
  ctx.fillStyle = "#d9f85b";
  ctx.beginPath();
  ctx.moveTo(0, -17);
  ctx.lineTo(15, 0);
  ctx.lineTo(0, 17);
  ctx.lineTo(-15, 0);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.fillStyle = "#26321b";
  ctx.font = "800 16px ui-monospace, monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("$", 0, 1);
  ctx.restore();
}

function drawScene(ctx: CanvasRenderingContext2D, game: Runtime, width: number, height: number, dpr: number, phase: Phase) {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#111819";
  ctx.fillRect(0, 0, width, height);
  const shake = phase === "playing" ? game.shake : 0;
  const shakeX = shake ? (Math.random() - 0.5) * shake : 0;
  const shakeY = shake ? (Math.random() - 0.5) * shake : 0;
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, width, height);
  ctx.clip();
  ctx.translate(shakeX, shakeY);
  ctx.translate(width / 2 - game.cameraX, height / 2 - game.cameraY);
  const left = game.cameraX - width / 2 - 20;
  const top = game.cameraY - height / 2 - 20;
  const right = game.cameraX + width / 2 + 20;
  const bottom = game.cameraY + height / 2 + 20;
  ctx.fillStyle = "#19211f";
  ctx.fillRect(left - GRID, top - GRID, right - left + GRID * 2, bottom - top + GRID * 2);

  const startBx = Math.floor(left / GRID) - 1;
  const endBx = Math.ceil(right / GRID) + 1;
  const startBy = Math.floor(top / GRID) - 1;
  const endBy = Math.ceil(bottom / GRID) + 1;
  for (let by = startBy; by <= endBy; by += 1) {
    for (let bx = startBx; bx <= endBx; bx += 1) {
      const design = getBlockDesign(bx, by);
      ctx.fillStyle = design.park ? "#354a3a" : "#343b37";
      ctx.fillRect(design.left, design.top, design.width, design.height);
      ctx.strokeStyle = "rgba(202,205,184,.22)";
      ctx.lineWidth = 1;
      ctx.strokeRect(design.left + 1, design.top + 1, design.width - 2, design.height - 2);
    }
  }
  drawRoads(ctx, left, top, right, bottom, game.visualTime);
  for (let by = startBy; by <= endBy; by += 1) {
    for (let bx = startBx; bx <= endBx; bx += 1) {
      const design = getBlockDesign(bx, by);
      if (design.park) drawPark(ctx, design, bx, by, game.visualTime);
      else design.rects.forEach((rect) => drawBuilding(ctx, rect, design.palette, design.variant, game.visualTime));
    }
  }
  drawTraffic(ctx, left, top, right, bottom, game.visualTime);
  game.pickups.forEach((pickup) => drawPickup(ctx, pickup, game.visualTime));
  game.cops.forEach((cop) => drawCar(ctx, cop.x, cop.y, cop.angle, "police", game.visualTime));
  game.particles.forEach((particle) => {
    const alpha = clamp(particle.life / particle.maxLife, 0, 1);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = particle.color;
    ctx.beginPath();
    ctx.arc(particle.x, particle.y, particle.size * (0.5 + alpha * 0.6), 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
  game.texts.forEach((text) => {
    ctx.globalAlpha = clamp(text.life / text.maxLife, 0, 1);
    ctx.font = "900 16px ui-monospace, monospace";
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(0,0,0,.75)";
    ctx.fillText(text.text, text.x + 1, text.y + 2);
    ctx.fillStyle = text.color;
    ctx.fillText(text.text, text.x, text.y);
  });
  ctx.globalAlpha = 1;
  drawCar(ctx, game.player.x, game.player.y, game.player.angle, "player", game.visualTime, game.player.boosting);
  ctx.restore();

  const vignette = ctx.createRadialGradient(width * 0.5, height * 0.48, Math.min(width, height) * 0.18, width * 0.5, height * 0.48, Math.max(width, height) * 0.76);
  vignette.addColorStop(0, "rgba(4,8,10,0)");
  vignette.addColorStop(1, "rgba(3,7,10,.52)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = "rgba(214,241,201,.023)";
  for (let y = 1; y < height; y += 4) ctx.fillRect(0, y, width, 1);
}

function StarIcon({ active }: { active: boolean }) {
  return (
    <svg className={`star-icon${active ? " is-active" : ""}`} viewBox="0 0 20 20" aria-hidden="true">
      <path d="m10 1.7 2.5 5.1 5.6.8-4.1 4 .97 5.65L10 14.58l-4.97 2.67L6 11.6l-4.1-4 5.6-.8L10 1.7Z" />
    </svg>
  );
}

function SoundIcon({ muted }: { muted: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 9v6h4l5 4V5L8 9H4Z" />
      {muted ? <path d="m17 9 5 6m0-6-5 6" /> : <><path d="M16 9a4 4 0 0 1 0 6" /><path d="M18.5 6.5a8 8 0 0 1 0 11" /></>}
    </svg>
  );
}

function PlayIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 11 7-11 7V5Z" /></svg>;
}

function PauseIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h4v14H7zM15 5h4v14h-4z" /></svg>;
}

function RecordTable({ records }: { records: RecordEntry[] }) {
  return (
    <div className="records-panel">
      <div className="records-heading">
        <span>LOCAL RUNS</span>
        <span className="records-cap">TOP 05</span>
      </div>
      <div className="records-table">
        {records.length === 0 ? (
          <div className="record-empty"><span>01</span><span>NO RUNS ON FILE</span><span>---</span></div>
        ) : records.slice(0, 5).map((record, index) => (
          <div className="record-row" key={`${record.date}-${index}`}>
            <span className="record-rank">{String(index + 1).padStart(2, "0")}</span>
            <span className="record-name">{record.name}<small>{record.date}</small></span>
            <span className="record-score">{formatMoney(record.score)}</span>
          </div>
        ))}
      </div>
      <div className="records-foot"><span>THIS DEVICE</span><span>NO CLOUD. NO MERCY.</span></div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const runtimeRef = useRef<Runtime>(createRuntime());
  const phaseRef = useRef<Phase>("menu");
  const keysRef = useRef<Record<string, boolean>>({});
  const touchRef = useRef<Vec>({ x: 0, y: 0 });
  const boostTouchRef = useRef(false);
  const driftTouchRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const soundEnabledRef = useRef(false);
  const scoreRecordsRef = useRef<RecordEntry[]>([]);
  const [phase, setPhase] = useState<Phase>("menu");
  const [records, setRecords] = useState<RecordEntry[]>(readRecords);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [touch, setTouch] = useState<Vec>({ x: 0, y: 0 });
  const [hud, setHud] = useState<HudSnapshot>(() => makeHud(runtimeRef.current));

  soundEnabledRef.current = soundEnabled;
  scoreRecordsRef.current = records;

  const setGamePhase = useCallback((next: Phase) => {
    phaseRef.current = next;
    setPhase(next);
  }, []);

  const playSfx = useCallback((kind: SoundKind) => {
    if (!soundEnabledRef.current || typeof window === "undefined") return;
    const AudioContextClass = window.AudioContext;
    if (!AudioContextClass) return;
    const audio = audioContextRef.current ?? new AudioContextClass();
    audioContextRef.current = audio;
    if (audio.state === "suspended") void audio.resume();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    const now = audio.currentTime;
    const tones: Record<SoundKind, [number, number, OscillatorType, number]> = {
      pickup: [680, 980, "sine", 0.16],
      boost: [150, 440, "sawtooth", 0.22],
      impact: [170, 70, "triangle", 0.2],
      busted: [320, 80, "sawtooth", 0.55],
    };
    const [startFrequency, endFrequency, wave, length] = tones[kind];
    oscillator.type = wave;
    oscillator.frequency.setValueAtTime(startFrequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(30, endFrequency), now + length);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(kind === "impact" ? 0.045 : 0.035, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + length);
    oscillator.connect(gain);
    gain.connect(audio.destination);
    oscillator.start(now);
    oscillator.stop(now + length + 0.02);
  }, []);

  const playSfxRef = useRef(playSfx);
  playSfxRef.current = playSfx;

  const toggleSound = useCallback(() => {
    setSoundEnabled((value) => {
      const next = !value;
      if (next && typeof window !== "undefined" && window.AudioContext) {
        const audio = audioContextRef.current ?? new window.AudioContext();
        audioContextRef.current = audio;
        if (audio.state === "suspended") void audio.resume();
      }
      return next;
    });
  }, []);

  const startGame = useCallback(() => {
    runtimeRef.current = createRuntime();
    keysRef.current = {};
    touchRef.current = { x: 0, y: 0 };
    boostTouchRef.current = false;
    driftTouchRef.current = false;
    setTouch({ x: 0, y: 0 });
    setHud(makeHud(runtimeRef.current));
    setGamePhase("playing");
  }, [setGamePhase]);

  const togglePause = useCallback(() => {
    if (phaseRef.current === "playing") {
      keysRef.current = {};
      boostTouchRef.current = false;
      driftTouchRef.current = false;
      touchRef.current = { x: 0, y: 0 };
      setTouch({ x: 0, y: 0 });
      setGamePhase("paused");
    } else if (phaseRef.current === "paused") {
      setGamePhase("playing");
    }
  }, [setGamePhase]);

  const finishRun = useCallback(() => {
    const game = runtimeRef.current;
    if (game.busted && phaseRef.current === "gameover") return;
    const entry: RecordEntry = {
      name: "DRIVER",
      score: game.score,
      distance: Math.round(game.distance),
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "2-digit" }).toUpperCase(),
    };
    const next = [...scoreRecordsRef.current, entry].sort((a, b) => b.score - a.score).slice(0, 5);
    scoreRecordsRef.current = next;
    setRecords(next);
    try {
      window.localStorage.setItem(RECORD_KEY, JSON.stringify(next));
    } catch {
      // The run still ends if storage is unavailable.
    }
    setHud(makeHud(game));
    setGamePhase("gameover");
    playSfxRef.current("busted");
    if (typeof navigator !== "undefined") navigator.vibrate?.([40, 40, 100]);
  }, [setGamePhase]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) return;
    let width = 1;
    let height = 1;
    let dpr = 1;
    let lastTime = performance.now();
    let lastHudUpdate = 0;
    let animationFrame = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(canvas);
    resize();

    const renderFrame = (time: number) => {
      const dt = Math.min(0.033, Math.max(0, (time - lastTime) / 1000));
      lastTime = time;
      const game = runtimeRef.current;
      const currentPhase = phaseRef.current;
      if (currentPhase === "playing") {
        const keys = keysRef.current;
        const stick = touchRef.current;
        const forwardKey = keys.w || keys.arrowup;
        const reverseKey = keys.s || keys.arrowdown;
        const leftKey = keys.a || keys.arrowleft;
        const rightKey = keys.d || keys.arrowright;
        const throttle = clamp(Math.max(forwardKey ? 1 : 0, -stick.y), 0, 1) - clamp(Math.max(reverseKey ? 1 : 0, stick.y), 0, 1);
        const steer = clamp((rightKey ? 1 : 0) - (leftKey ? 1 : 0) + stick.x, -1, 1);
        const ended = updateGame(game, dt, {
          throttle,
          steer,
          drift: Boolean(keys.shift || driftTouchRef.current),
          boost: Boolean(keys[" "] || keys.space || boostTouchRef.current),
        }, (kind) => playSfxRef.current(kind));
        if (ended) finishRun();
      } else {
        game.visualTime += dt;
        if (currentPhase === "menu") {
          game.cameraX = Math.sin(game.visualTime * 0.14) * 18;
          game.cameraY = Math.cos(game.visualTime * 0.12) * 11;
        }
      }
      if (time - lastHudUpdate > 110) {
        setHud(makeHud(game));
        lastHudUpdate = time;
      }
      drawScene(context, game, width, height, dpr, phaseRef.current);
      animationFrame = requestAnimationFrame(renderFrame);
    };
    animationFrame = requestAnimationFrame(renderFrame);
    return () => {
      cancelAnimationFrame(animationFrame);
      resizeObserver.disconnect();
    };
  }, [finishRun]);

  useEffect(() => {
    const preventKeys = new Set(["arrowup", "arrowdown", "arrowleft", "arrowright", " "]);
    const onKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (preventKeys.has(key)) event.preventDefault();
      if (key === "enter") {
        if (phaseRef.current === "menu" || phaseRef.current === "gameover") startGame();
        else if (phaseRef.current === "paused") setGamePhase("playing");
      }
      if (key === "escape" || key === "p") togglePause();
      if (key === "r" && phaseRef.current === "gameover") startGame();
      if (key === "m") toggleSound();
      keysRef.current[key] = true;
    };
    const onKeyUp = (event: KeyboardEvent) => {
      keysRef.current[event.key.toLowerCase()] = false;
    };
    const onBlur = () => {
      keysRef.current = {};
      boostTouchRef.current = false;
      driftTouchRef.current = false;
      touchRef.current = { x: 0, y: 0 };
      setTouch({ x: 0, y: 0 });
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, [setGamePhase, startGame, togglePause, toggleSound]);

  const updateStick = (event: ReactPointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const radius = rect.width * 0.34;
    const dx = event.clientX - (rect.left + rect.width / 2);
    const dy = event.clientY - (rect.top + rect.height / 2);
    const length = Math.hypot(dx, dy);
    const scale = length > radius ? radius / length : 1;
    const next = { x: clamp((dx * scale) / radius, -1, 1), y: clamp((dy * scale) / radius, -1, 1) };
    touchRef.current = next;
    setTouch(next);
  };

  const resetStick = () => {
    touchRef.current = { x: 0, y: 0 };
    setTouch({ x: 0, y: 0 });
  };

  const bestScore = records[0]?.score ?? 0;
  const isLive = phase === "playing" || phase === "paused" || phase === "gameover";

  return (
    <main className="page-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark" aria-hidden="true"><span /><span /><span /></div>
          <div className="brand-wordmark"><span>NIGHT</span><span>SHIFT</span></div>
          <span className="brand-edition">ARCADE / 01</span>
        </div>
        <div className="topbar-right">
          <span className="service-status"><i /> CITY SERVICE ONLINE</span>
          <button className={`sound-button${soundEnabled ? " is-on" : ""}`} onClick={toggleSound} aria-label={soundEnabled ? "Turn sound effects off" : "Turn sound effects on"}>
            <SoundIcon muted={!soundEnabled} />
            <span>{soundEnabled ? "SFX ON" : "SFX OFF"}</span>
          </button>
        </div>
      </header>

      <section className={`game-stage${phase === "playing" ? " is-playing" : ""}`} aria-label="Night Shift getaway game">
        <canvas ref={canvasRef} className="game-canvas" aria-label="Top-down neon city driving game" />

        {phase === "menu" && (
          <div className="menu-overlay">
            <div className="menu-layout">
              <div className="menu-copy">
                <div className="eyebrow"><span className="eyebrow-line" /> AFTER HOURS <span className="eyebrow-separator">/</span> WEST DISTRICT</div>
                <h1>NIGHT<br /><em>SHIFT</em></h1>
                <p className="menu-subtitle">Grab the drop. Lose the blue lights.<br className="desktop-break" /> Own the night.</p>
                <div className="menu-actions">
                  <button className="primary-button" onClick={startGame}>
                    <span>START THE RUN</span><span className="button-icon"><PlayIcon /></span>
                  </button>
                  <span className="enter-hint">PRESS <kbd>ENTER</kbd></span>
                </div>
                <div className="quick-rules"><span>+$300 PER DROP</span><i /> <span>EVERY SCORE ADDS HEAT</span></div>
                <div className="menu-controls">
                  <span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> DRIVE</span>
                  <span><kbd>SPACE</kbd> NITRO</span>
                  <span><kbd>SHIFT</kbd> DRIFT</span>
                </div>
              </div>
              <RecordTable records={records} />
            </div>
            <div className="menu-corner"><span>40.712° N</span><i /> <span>03:17 AM</span></div>
          </div>
        )}

        {isLive && (
          <div className={`live-hud${phase === "paused" || phase === "gameover" ? " is-dimmed" : ""}`}>
            <div className="hud-topline">
              <div className="hud-take">
                <span className="hud-label">RUN TAKE <b>USD</b></span>
                <span className="take-value" key={hud.pickupCount}>{formatMoney(hud.score)}</span>
              </div>
              <div className="heat-readout">
                <span className="hud-label">WANTED LEVEL</span>
                <div className="heat-stars">
                  {Array.from({ length: 5 }, (_, index) => <StarIcon key={index} active={hud.wanted >= index + 0.45} />)}
                </div>
              </div>
              <div className="vehicle-readout">
                <span className="hud-label">VEHICLE CONDITION <b>{Math.round(hud.health)}%</b></span>
                <div className="condition-track"><span style={{ width: `${clamp(hud.health, 0, 100)}%` }} /></div>
                {hud.bust > 1 && <div className="bust-track"><span style={{ width: `${clamp(hud.bust, 0, 100)}%` }} /></div>}
              </div>
              {phase === "playing" && <button className="pause-button" onClick={togglePause} aria-label="Pause game"><PauseIcon /></button>}
            </div>
            <div className="boost-readout">
              <span className="hud-label">NITRO <b>{Math.round(hud.boost)}%</b></span>
              <div className="boost-track"><span style={{ width: `${clamp(hud.boost, 0, 100)}%` }} /></div>
              <span className="speed-readout"><b>{String(hud.speed).padStart(3, "0")}</b> KM/H</span>
            </div>
            {phase === "playing" && <div className="chase-count"><span className="chase-dot" /> {hud.cops ? `${String(hud.cops).padStart(2, "0")} UNITS IN PURSUIT` : "NO UNITS IN SIGHT"}</div>}
          </div>
        )}

        {phase === "paused" && (
          <div className="state-overlay pause-overlay">
            <div className="state-content">
              <span className="state-overline">ENGINE IDLING</span>
              <h2>PAUSED</h2>
              <p>The city can wait. The heat won't.</p>
              <button className="primary-button" onClick={() => setGamePhase("playing")}>
                <span>BACK TO THE RUN</span><span className="button-icon"><PlayIcon /></span>
              </button>
              <button className="text-button" onClick={startGame}>ABANDON RUN <span>-&gt;</span></button>
              <span className="state-keyhint"><kbd>ESC</kbd> RESUME</span>
            </div>
          </div>
        )}

        {phase === "gameover" && (
          <div className="state-overlay gameover-overlay">
            <div className="state-content gameover-content">
              <span className="state-overline busted-overline"><i /> PURSUIT TERMINATED</span>
              <h2>BUSTED<span>.</span></h2>
              <p>That's one way to end a night.</p>
              <div className="final-take"><span>YOUR TAKE</span><strong>{formatMoney(hud.score)}</strong></div>
              <div className="best-line"><span>LOCAL BEST</span><b>{formatMoney(Math.max(bestScore, hud.score))}</b></div>
              <button className="primary-button restart-button" onClick={startGame}>
                <span>RUN IT BACK</span><span className="button-icon"><PlayIcon /></span>
              </button>
              <span className="state-keyhint"><kbd>ENTER</kbd> INSTANT RESTART</span>
            </div>
          </div>
        )}

        {phase === "playing" && (
          <div className="touch-controls" aria-label="Touch driving controls">
            <div
              className="joystick"
              aria-label="Steering and throttle joystick"
              onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); updateStick(event); }}
              onPointerMove={(event) => { if (event.buttons > 0) updateStick(event); }}
              onPointerUp={resetStick}
              onPointerCancel={resetStick}
              onLostPointerCapture={resetStick}
            >
              <span className="joystick-ring" /><span className="joystick-center" />
              <span className="joystick-thumb" style={{ transform: `translate(calc(-50% + ${touch.x * 29}px), calc(-50% + ${touch.y * 29}px))` }} />
              <span className="joystick-caption">DRIVE</span>
            </div>
            <div className="action-controls">
              <button
                className={`touch-action drift-action${driftTouchRef.current ? " is-held" : ""}`}
                aria-label="Hold to drift"
                onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); driftTouchRef.current = true; event.currentTarget.classList.add("is-held"); }}
                onPointerUp={(event) => { driftTouchRef.current = false; event.currentTarget.classList.remove("is-held"); }}
                onPointerCancel={(event) => { driftTouchRef.current = false; event.currentTarget.classList.remove("is-held"); }}
                onLostPointerCapture={(event) => { driftTouchRef.current = false; event.currentTarget.classList.remove("is-held"); }}
              >DRIFT</button>
              <button
                className="touch-action nitro-action"
                aria-label="Hold to use nitro"
                onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); boostTouchRef.current = true; event.currentTarget.classList.add("is-held"); }}
                onPointerUp={(event) => { boostTouchRef.current = false; event.currentTarget.classList.remove("is-held"); }}
                onPointerCancel={(event) => { boostTouchRef.current = false; event.currentTarget.classList.remove("is-held"); }}
                onLostPointerCapture={(event) => { boostTouchRef.current = false; event.currentTarget.classList.remove("is-held"); }}
              >
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.2 2 5 13h5l-.7 9L19 10h-5.2L13.2 2Z" /></svg>
                <span>NITRO</span>
              </button>
            </div>
          </div>
        )}
      </section>

      <footer className="game-footer">
        <div className="footer-controls"><span className="footer-label">CONTROLS</span><span><kbd>W A S D</kbd> DRIVE</span><span><kbd>SPACE</kbd> NITRO</span><span><kbd>SHIFT</kbd> DRIFT</span><span><kbd>P</kbd> PAUSE</span></div>
        <div className="footer-record"><span>LOCAL BEST</span><b>{formatMoney(bestScore)}</b></div>
      </footer>
      <div className="mobile-footnote"><span>TOUCH STICK TO DRIVE</span><i /> <span>HOLD NITRO TO BREAK AWAY</span></div>
    </main>
  );
}